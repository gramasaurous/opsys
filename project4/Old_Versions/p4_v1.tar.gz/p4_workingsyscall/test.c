#include <stdio.h>
#include <stdlib.h>

int main (void) {
	return(setkey(15,21));
}
