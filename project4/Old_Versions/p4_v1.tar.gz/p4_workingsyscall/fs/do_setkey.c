/* Graham Greving
 * CMPS111: Project 4
 * setkey.c
 * setkey() system call handler
 * Creates an AES encryption key for the current user with the defined integers
 */

#include <stdio.h>
#include <stdlib.h>
#include "fs.h"
#include "lib.h"

PUBLIC int do_setkey(void) {
	
	unsigned int k0 = m_in.m1_i1;
	unsigned int k1 = m_in.m1_i2;
	
	printf("setkey(%d, %d)\n",k0,k1);
}
